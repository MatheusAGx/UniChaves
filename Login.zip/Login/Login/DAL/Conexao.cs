﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniChaves.Apresentação;

namespace UniChaves
{
    public class Conexao
    {
        private MySqlConnection conexao;
        private string stringConexao = "server=143.106.241.3;database=cl203168;uid=cl203168;pwd=cl*15061998;";

        // Construtor
        public Conexao()
        {
            conexao = new MySqlConnection(stringConexao);
        }

        public MySqlConnection Conectar() {
            try
            {
                if (conexao.State == System.Data.ConnectionState.Closed)
                {
                    conexao.Open();
                    Console.WriteLine("Conexão aberta com sucesso!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao abrir conexão: {ex.Message}");
            }

            return conexao;
        }

        public void Desconectar() 
        {
            try
            {
                if (conexao.State == System.Data.ConnectionState.Open)
                {
                    conexao.Close();
                    Console.WriteLine("Conexão fechada com sucesso!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao fechar conexão: {ex.Message}");
            }

        }

        public void ExecuteQuery(string query)
        {
            try
            {
                this.Conectar();
                MySqlCommand command = new MySqlCommand(query, conexao);
                command.ExecuteNonQuery();
                Console.WriteLine("Query executada com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao executar query: {ex.Message}");
            }
            finally
            {
                this.Desconectar();
            }
        }

        public bool Login(string usuario, string senha)
        {
            try
            {
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conexao;
                comando.CommandText = "SELECT cpf, senha FROM usuarios WHERE nome = @usuario AND senha = @senha";
                comando.Parameters.AddWithValue("@usuario", usuario);
                comando.Parameters.AddWithValue("@senha", senha);
                MySqlDataReader leitor = comando.ExecuteReader();

                if (leitor.HasRows)
                {
                    Início form = new Início();
                    form.Show();
                    return true;
                }
                else
                {
                    MessageBox.Show("Dados inválidos! Por favor tente novamente!", "Aviso do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }; // Usuário não encontrado
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar","Aviso do sistema", MessageBoxButtons.OK,MessageBoxIcon.Information);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

    }

}