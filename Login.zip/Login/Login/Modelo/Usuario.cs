﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniChaves.Modelo
{
    public class Usuario
    {
        private int id { get; set; }
        private string nome { get; set; }
        private string senha { get; set; }
        private string cpf { get; set; }
        private string cnpj { get; set; }
        private string email { get; set; }
        private string telefone { get; set; }
        private string endereco { get; set; }
        private string bairro { get; set; }
        private string cep { get; set; }
        private int numero { get; set; }
        private string cidade { get; set; }
        private string uf { get; set; }

        private int status { get; set; }

        private int tipo { get; set; }

        public Usuario(int id, string nome, string senha, string cpf, string cnpj, string email, string telefone, string endereco, string bairro, string cep, int numero, string cidade, string uf, int status, int tipo)
        {
            this.id = id;
            this.nome = nome;
            this.senha = senha;
            this.cpf = cpf;
            this.cnpj = cnpj;
            this.email = email;
            this.telefone = telefone;
            this.endereco = endereco;
            this.bairro = bairro;
            this.cep = cep;
            this.numero = numero;
            this.cidade = cidade;
            this.uf = uf;
            this.status = status;
            this.tipo = tipo;
        }

        public Usuario()
        {
        }

        public override bool Equals(object? obj)
        {
            return obj is Usuario usuario &&
                   id == usuario.id &&
                   nome == usuario.nome &&
                   senha == usuario.senha &&
                   cpf == usuario.cpf &&
                   cnpj == usuario.cnpj &&
                   email == usuario.email &&
                   telefone == usuario.telefone &&
                   endereco == usuario.endereco &&
                   bairro == usuario.bairro &&
                   cep == usuario.cep &&
                   numero == usuario.numero &&
                   cidade == usuario.cidade &&
                   uf == usuario.uf &&
                   status == usuario.status &&
                   tipo == usuario.tipo;
        }

        public override int GetHashCode()
        {
            HashCode hash = new HashCode();
            hash.Add(id);
            hash.Add(nome);
            hash.Add(senha);
            hash.Add(cpf);
            hash.Add(cnpj);
            hash.Add(email);
            hash.Add(telefone);
            hash.Add(endereco);
            hash.Add(bairro);
            hash.Add(cep);
            hash.Add(numero);
            hash.Add(cidade);
            hash.Add(uf);
            hash.Add(status);
            hash.Add(tipo);
            return hash.ToHashCode();
        }
    }
}
