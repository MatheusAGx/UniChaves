﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniChaves.Modelo
{
    public class Chave
    {
        private int id { get; set; }
        private string nome { get; set; }
        private string descricao { get; set; }
        private string instituicao { get; set; }
        private int status { get; set; }
        private Usuario usuario { get; set; }

        public Chave(int id, string nome, string descricao, string instituicao, int status, Usuario usuario)
        {
            this.id = id;
            this.nome = nome;
            this.descricao = descricao;
            this.instituicao = instituicao;
            this.status = status;
            this.usuario = usuario;
        }

        public Chave()
        { 
        }

        public override bool Equals(object? obj)
        {
            return obj is Chave chave &&
                   id == chave.id &&
                   nome == chave.nome &&
                   descricao == chave.descricao &&
                   instituicao == chave.instituicao &&
                   status == chave.status &&
                   EqualityComparer<Usuario>.Default.Equals(usuario, chave.usuario);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(id, nome, descricao, instituicao, status, usuario);
        }
    }
}
