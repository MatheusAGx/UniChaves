using UniChaves;
using Microsoft.VisualBasic.Devices;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void btnEntrar_Click(object sender, EventArgs e)
        {

            var conexao = new Conexao();
            conexao.Conectar();
            string usuarioStr = txtUsuario.Text; // Substitua 'txtUsuario' pelo nome real do seu TextBox de usu�rio
            string senha = txtSenha.Text; // Substitua 'txtSenha' pelo nome real do seu TextBox de senha
            conexao.Login(usuarioStr, senha);
           
        }

        }
}

        