﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniChaves.Apresentação
{
    public partial class CadUsuario : Form
    {
        public CadUsuario()
        {
            InitializeComponent();
            txtNome.Focus();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Conexao con = new Conexao();
            con.Conectar();

            if (txtEmail.Text != "@gmail.com" || txtEmail.Text != "@hotmail.com" || txtEmail.Text != "@outlook.com")
            {
                MessageBox.Show("Este e-mail não é válido!", "Aviso do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtEmail.Focus();
            }
            else if (txtNome.Text == "" || txtCidade.Text == "" || txtBairro.Text == "" || txtNumero.Text == "" || txtCpf.Text == "" || txtCnpj.Text == "" || txtCep.Text == "" || txtEmail.Text == "")
            {
                MessageBox.Show("Por favor! Preencha todos os campos!", "Aviso do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.ExecuteQuery("INSERT INTO cl203168.usuarios () VALUES ()");
            }
        }
    }
}
