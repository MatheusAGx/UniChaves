﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniChaves.Apresentação
{
    public partial class Usuario : Form
    {
        public Usuario()
        {
            InitializeComponent();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            Conexao conexao = new Conexao();
            conexao.Conectar();
            conexao.ExecuteQuery("SELECT nome, cpf, email, telefone, endereco, bairro, numero, cidade FROM cl203168.usuarios");
            conexao.Desconectar();

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            CadUsuario form = new CadUsuario();
            form.Show();
        }

        private void Usuario_Load(object sender, EventArgs e)
        {
            Conexao con = new Conexao();

            string querySelect = "SELECT * FROM cl203168.usuarios";

            try 
            {
                con.Conectar();

                MySqlCommand comando = new MySqlCommand(querySelect, con.Conectar());
                MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                DataTable tabela = new DataTable();

                adaptador.Fill(tabela);
                dataUsuario.DataSource = tabela;
            } 
            catch (Exception ex) 
            {
                MessageBox.Show("Erro" + ex.Message);
            }
            finally
            {
                con.Desconectar();
            }
           
        }
    }
}
