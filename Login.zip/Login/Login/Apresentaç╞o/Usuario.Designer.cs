﻿namespace UniChaves.Apresentação
{
    partial class Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataUsuario = new DataGridView();
            Status = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            Senha = new DataGridViewTextBoxColumn();
            CPF = new DataGridViewTextBoxColumn();
            CNPJ = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            Telefone = new DataGridViewTextBoxColumn();
            Endereço = new DataGridViewTextBoxColumn();
            Bairro = new DataGridViewTextBoxColumn();
            CEP = new DataGridViewTextBoxColumn();
            Numero = new DataGridViewTextBoxColumn();
            Cidade = new DataGridViewTextBoxColumn();
            UF = new DataGridViewTextBoxColumn();
            conexaoBindingSource = new BindingSource(components);
            statusStrip1 = new StatusStrip();
            lblNome = new Label();
            txtNome = new TextBox();
            txtEmail = new TextBox();
            lblEmail = new Label();
            txtCnpj = new TextBox();
            lblCnpj = new Label();
            panel1 = new Panel();
            btnAdicionar = new Button();
            btnDeletar = new Button();
            btnEditar = new Button();
            txtTel = new TextBox();
            lblTelefone = new Label();
            txtCpf = new TextBox();
            lblCpf = new Label();
            btnLimparFiltro = new Button();
            btnFiltrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataUsuario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataUsuario
            // 
            dataUsuario.AutoGenerateColumns = false;
            dataUsuario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataUsuario.Columns.AddRange(new DataGridViewColumn[] { Status, Nome, Senha, CPF, CNPJ, Email, Telefone, Endereço, Bairro, CEP, Numero, Cidade, UF });
            dataUsuario.DataSource = conexaoBindingSource;
            dataUsuario.Location = new Point(27, 97);
            dataUsuario.Margin = new Padding(2, 2, 2, 2);
            dataUsuario.Name = "dataUsuario";
            dataUsuario.RowHeadersWidth = 62;
            dataUsuario.Size = new Size(746, 182);
            dataUsuario.TabIndex = 0;
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.MinimumWidth = 8;
            Status.Name = "Status";
            Status.Width = 150;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 8;
            Nome.Name = "Nome";
            Nome.Width = 150;
            // 
            // Senha
            // 
            Senha.HeaderText = "Senha";
            Senha.MinimumWidth = 8;
            Senha.Name = "Senha";
            Senha.Width = 150;
            // 
            // CPF
            // 
            CPF.HeaderText = "CPF";
            CPF.MinimumWidth = 8;
            CPF.Name = "CPF";
            CPF.Width = 150;
            // 
            // CNPJ
            // 
            CNPJ.HeaderText = "CNPJ";
            CNPJ.MinimumWidth = 8;
            CNPJ.Name = "CNPJ";
            CNPJ.Width = 150;
            // 
            // Email
            // 
            Email.HeaderText = "Email";
            Email.MinimumWidth = 8;
            Email.Name = "Email";
            Email.Width = 150;
            // 
            // Telefone
            // 
            Telefone.HeaderText = "Telefone";
            Telefone.MinimumWidth = 8;
            Telefone.Name = "Telefone";
            Telefone.Width = 150;
            // 
            // Endereço
            // 
            Endereço.HeaderText = "Endereço";
            Endereço.MinimumWidth = 8;
            Endereço.Name = "Endereço";
            Endereço.Width = 150;
            // 
            // Bairro
            // 
            Bairro.HeaderText = "Bairro";
            Bairro.MinimumWidth = 8;
            Bairro.Name = "Bairro";
            Bairro.Width = 150;
            // 
            // CEP
            // 
            CEP.HeaderText = "CEP";
            CEP.MinimumWidth = 8;
            CEP.Name = "CEP";
            CEP.Width = 150;
            // 
            // Numero
            // 
            Numero.HeaderText = "Numero";
            Numero.MinimumWidth = 8;
            Numero.Name = "Numero";
            Numero.Width = 150;
            // 
            // Cidade
            // 
            Cidade.HeaderText = "Cidade";
            Cidade.MinimumWidth = 8;
            Cidade.Name = "Cidade";
            Cidade.Width = 150;
            // 
            // UF
            // 
            UF.HeaderText = "UF";
            UF.MinimumWidth = 8;
            UF.Name = "UF";
            UF.Width = 150;
            // 
            // conexaoBindingSource
            // 
            conexaoBindingSource.DataSource = typeof(Conexao);
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Location = new Point(0, 330);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Padding = new Padding(1, 0, 10, 0);
            statusStrip1.Size = new Size(799, 22);
            statusStrip1.TabIndex = 1;
            statusStrip1.Text = "statusStrip1";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(27, 19);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(43, 15);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(73, 17);
            txtNome.Margin = new Padding(2, 2, 2, 2);
            txtNome.MaxLength = 255;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(254, 23);
            txtNome.TabIndex = 4;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(384, 17);
            txtEmail.Margin = new Padding(2, 2, 2, 2);
            txtEmail.MaxLength = 255;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(260, 23);
            txtEmail.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(339, 19);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(39, 15);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email:";
            // 
            // txtCnpj
            // 
            txtCnpj.Location = new Point(73, 48);
            txtCnpj.Margin = new Padding(2, 2, 2, 2);
            txtCnpj.MaxLength = 14;
            txtCnpj.Name = "txtCnpj";
            txtCnpj.Size = new Size(179, 23);
            txtCnpj.TabIndex = 8;
            // 
            // lblCnpj
            // 
            lblCnpj.AutoSize = true;
            lblCnpj.Location = new Point(27, 50);
            lblCnpj.Margin = new Padding(2, 0, 2, 0);
            lblCnpj.Name = "lblCnpj";
            lblCnpj.Size = new Size(37, 15);
            lblCnpj.TabIndex = 7;
            lblCnpj.Text = "CNPJ:";
            // 
            // panel1
            // 
            panel1.Controls.Add(btnAdicionar);
            panel1.Controls.Add(btnDeletar);
            panel1.Controls.Add(btnEditar);
            panel1.Controls.Add(txtTel);
            panel1.Controls.Add(lblTelefone);
            panel1.Controls.Add(txtCpf);
            panel1.Controls.Add(lblCpf);
            panel1.Controls.Add(btnLimparFiltro);
            panel1.Controls.Add(btnFiltrar);
            panel1.Controls.Add(lblNome);
            panel1.Controls.Add(txtCnpj);
            panel1.Controls.Add(dataUsuario);
            panel1.Controls.Add(txtNome);
            panel1.Controls.Add(lblCnpj);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(txtEmail);
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(2, 2, 2, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(799, 337);
            panel1.TabIndex = 9;
            // 
            // btnAdicionar
            // 
            btnAdicionar.Location = new Point(27, 301);
            btnAdicionar.Margin = new Padding(2, 2, 2, 2);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(78, 20);
            btnAdicionar.TabIndex = 17;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = true;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // btnDeletar
            // 
            btnDeletar.Location = new Point(695, 301);
            btnDeletar.Margin = new Padding(2, 2, 2, 2);
            btnDeletar.Name = "btnDeletar";
            btnDeletar.Size = new Size(78, 20);
            btnDeletar.TabIndex = 16;
            btnDeletar.Text = "Deletar";
            btnDeletar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(603, 301);
            btnEditar.Margin = new Padding(2, 2, 2, 2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(78, 20);
            btnEditar.TabIndex = 15;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(485, 48);
            txtTel.Margin = new Padding(2, 2, 2, 2);
            txtTel.MaxLength = 11;
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(160, 23);
            txtTel.TabIndex = 14;
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(452, 50);
            lblTelefone.Margin = new Padding(2, 0, 2, 0);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(24, 15);
            lblTelefone.TabIndex = 13;
            lblTelefone.Text = "Tel:";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(288, 48);
            txtCpf.Margin = new Padding(2, 2, 2, 2);
            txtCpf.MaxLength = 11;
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(160, 23);
            txtCpf.TabIndex = 12;
            // 
            // lblCpf
            // 
            lblCpf.AutoSize = true;
            lblCpf.Location = new Point(255, 50);
            lblCpf.Margin = new Padding(2, 0, 2, 0);
            lblCpf.Name = "lblCpf";
            lblCpf.Size = new Size(31, 15);
            lblCpf.TabIndex = 11;
            lblCpf.Text = "CPF:";
            // 
            // btnLimparFiltro
            // 
            btnLimparFiltro.Location = new Point(663, 50);
            btnLimparFiltro.Margin = new Padding(2, 2, 2, 2);
            btnLimparFiltro.Name = "btnLimparFiltro";
            btnLimparFiltro.Size = new Size(111, 20);
            btnLimparFiltro.TabIndex = 10;
            btnLimparFiltro.Text = "Limpar Filtro";
            btnLimparFiltro.UseVisualStyleBackColor = true;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(663, 15);
            btnFiltrar.Margin = new Padding(2, 2, 2, 2);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(111, 20);
            btnFiltrar.TabIndex = 9;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // Usuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(799, 352);
            Controls.Add(panel1);
            Controls.Add(statusStrip1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(2, 2, 2, 2);
            Name = "Usuario";
            Text = "Usuario";
            Load += Usuario_Load;
            ((System.ComponentModel.ISupportInitialize)dataUsuario).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataUsuario;
        private StatusStrip statusStrip1;
        private Label lblNome;
        private TextBox txtNome;
        private TextBox txtEmail;
        private Label lblEmail;
        private TextBox txtCnpj;
        private Label lblCnpj;
        private Panel panel1;
        private TextBox txtTel;
        private Label lblTelefone;
        private TextBox txtCpf;
        private Label lblCpf;
        private Button btnLimparFiltro;
        private Button btnFiltrar;
        private BindingSource conexaoBindingSource;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn Nome;
        private Button btnAdicionar;
        private Button btnDeletar;
        private Button btnEditar;
        private DataGridViewTextBoxColumn Senha;
        private DataGridViewTextBoxColumn CPF;
        private DataGridViewTextBoxColumn CNPJ;
        private DataGridViewTextBoxColumn Email;
        private DataGridViewTextBoxColumn Telefone;
        private DataGridViewTextBoxColumn Endereço;
        private DataGridViewTextBoxColumn Bairro;
        private DataGridViewTextBoxColumn CEP;
        private DataGridViewTextBoxColumn Numero;
        private DataGridViewTextBoxColumn Cidade;
        private DataGridViewTextBoxColumn UF;
    }
}