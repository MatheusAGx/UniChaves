﻿namespace UniChaves.Apresentação
{
    partial class Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataUsuario = new DataGridView();
            Status = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            Senha = new DataGridViewTextBoxColumn();
            CPF = new DataGridViewTextBoxColumn();
            CNPJ = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            Telefone = new DataGridViewTextBoxColumn();
            Endereço = new DataGridViewTextBoxColumn();
            Bairro = new DataGridViewTextBoxColumn();
            CEP = new DataGridViewTextBoxColumn();
            Numero = new DataGridViewTextBoxColumn();
            Cidade = new DataGridViewTextBoxColumn();
            UF = new DataGridViewTextBoxColumn();
            conexaoBindingSource = new BindingSource(components);
            statusStrip1 = new StatusStrip();
            lblNome = new Label();
            txtNome = new TextBox();
            txtEmail = new TextBox();
            lblEmail = new Label();
            txtCnpj = new TextBox();
            lblCnpj = new Label();
            panel1 = new Panel();
            btnAdicionar = new Button();
            btnDeletar = new Button();
            btnEditar = new Button();
            txtTel = new TextBox();
            lblTelefone = new Label();
            txtCpf = new TextBox();
            lblCpf = new Label();
            btnLimparFiltro = new Button();
            btnFiltrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataUsuario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataUsuario
            // 
            dataUsuario.AutoGenerateColumns = false;
            dataUsuario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataUsuario.Columns.AddRange(new DataGridViewColumn[] { Status, Nome, Senha, CPF, CNPJ, Email, Telefone, Endereço, Bairro, CEP, Numero, Cidade, UF });
            dataUsuario.DataSource = conexaoBindingSource;
            dataUsuario.Location = new Point(39, 161);
            dataUsuario.Name = "dataUsuario";
            dataUsuario.RowHeadersWidth = 62;
            dataUsuario.Size = new Size(1066, 304);
            dataUsuario.TabIndex = 0;
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.MinimumWidth = 8;
            Status.Name = "Status";
            Status.Width = 150;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 8;
            Nome.Name = "Nome";
            Nome.Width = 150;
            // 
            // Senha
            // 
            Senha.HeaderText = "Senha";
            Senha.MinimumWidth = 8;
            Senha.Name = "Senha";
            Senha.Width = 150;
            // 
            // CPF
            // 
            CPF.HeaderText = "CPF";
            CPF.MinimumWidth = 8;
            CPF.Name = "CPF";
            CPF.Width = 150;
            // 
            // CNPJ
            // 
            CNPJ.HeaderText = "CNPJ";
            CNPJ.MinimumWidth = 8;
            CNPJ.Name = "CNPJ";
            CNPJ.Width = 150;
            // 
            // Email
            // 
            Email.HeaderText = "Email";
            Email.MinimumWidth = 8;
            Email.Name = "Email";
            Email.Width = 150;
            // 
            // Telefone
            // 
            Telefone.HeaderText = "Telefone";
            Telefone.MinimumWidth = 8;
            Telefone.Name = "Telefone";
            Telefone.Width = 150;
            // 
            // Endereço
            // 
            Endereço.HeaderText = "Endereço";
            Endereço.MinimumWidth = 8;
            Endereço.Name = "Endereço";
            Endereço.Width = 150;
            // 
            // Bairro
            // 
            Bairro.HeaderText = "Bairro";
            Bairro.MinimumWidth = 8;
            Bairro.Name = "Bairro";
            Bairro.Width = 150;
            // 
            // CEP
            // 
            CEP.HeaderText = "CEP";
            CEP.MinimumWidth = 8;
            CEP.Name = "CEP";
            CEP.Width = 150;
            // 
            // Numero
            // 
            Numero.HeaderText = "Numero";
            Numero.MinimumWidth = 8;
            Numero.Name = "Numero";
            Numero.Width = 150;
            // 
            // Cidade
            // 
            Cidade.HeaderText = "Cidade";
            Cidade.MinimumWidth = 8;
            Cidade.Name = "Cidade";
            Cidade.Width = 150;
            // 
            // UF
            // 
            UF.HeaderText = "UF";
            UF.MinimumWidth = 8;
            UF.Name = "UF";
            UF.Width = 150;
            // 
            // conexaoBindingSource
            // 
            conexaoBindingSource.DataSource = typeof(Conexao);
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Location = new Point(0, 564);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1142, 22);
            statusStrip1.TabIndex = 1;
            statusStrip1.Text = "statusStrip1";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(39, 31);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(65, 25);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(104, 28);
            txtNome.MaxLength = 255;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(361, 31);
            txtNome.TabIndex = 4;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(548, 28);
            txtEmail.MaxLength = 255;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(370, 31);
            txtEmail.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(484, 31);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(58, 25);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email:";
            // 
            // txtCnpj
            // 
            txtCnpj.Location = new Point(104, 80);
            txtCnpj.MaxLength = 14;
            txtCnpj.Name = "txtCnpj";
            txtCnpj.Size = new Size(254, 31);
            txtCnpj.TabIndex = 8;
            // 
            // lblCnpj
            // 
            lblCnpj.AutoSize = true;
            lblCnpj.Location = new Point(39, 83);
            lblCnpj.Name = "lblCnpj";
            lblCnpj.Size = new Size(55, 25);
            lblCnpj.TabIndex = 7;
            lblCnpj.Text = "CNPJ:";
            // 
            // panel1
            // 
            panel1.Controls.Add(btnAdicionar);
            panel1.Controls.Add(btnDeletar);
            panel1.Controls.Add(btnEditar);
            panel1.Controls.Add(txtTel);
            panel1.Controls.Add(lblTelefone);
            panel1.Controls.Add(txtCpf);
            panel1.Controls.Add(lblCpf);
            panel1.Controls.Add(btnLimparFiltro);
            panel1.Controls.Add(btnFiltrar);
            panel1.Controls.Add(lblNome);
            panel1.Controls.Add(txtCnpj);
            panel1.Controls.Add(dataUsuario);
            panel1.Controls.Add(txtNome);
            panel1.Controls.Add(lblCnpj);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(txtEmail);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1142, 561);
            panel1.TabIndex = 9;
            // 
            // btnAdicionar
            // 
            btnAdicionar.Location = new Point(39, 501);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(112, 34);
            btnAdicionar.TabIndex = 17;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = true;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // btnDeletar
            // 
            btnDeletar.Location = new Point(993, 501);
            btnDeletar.Name = "btnDeletar";
            btnDeletar.Size = new Size(112, 34);
            btnDeletar.TabIndex = 16;
            btnDeletar.Text = "Deletar";
            btnDeletar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(862, 501);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(112, 34);
            btnEditar.TabIndex = 15;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(693, 80);
            txtTel.MaxLength = 11;
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(227, 31);
            txtTel.TabIndex = 14;
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(645, 83);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(36, 25);
            lblTelefone.TabIndex = 13;
            lblTelefone.Text = "Tel:";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(412, 80);
            txtCpf.MaxLength = 11;
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(227, 31);
            txtCpf.TabIndex = 12;
            // 
            // lblCpf
            // 
            lblCpf.AutoSize = true;
            lblCpf.Location = new Point(364, 83);
            lblCpf.Name = "lblCpf";
            lblCpf.Size = new Size(46, 25);
            lblCpf.TabIndex = 11;
            lblCpf.Text = "CPF:";
            // 
            // btnLimparFiltro
            // 
            btnLimparFiltro.Location = new Point(947, 83);
            btnLimparFiltro.Name = "btnLimparFiltro";
            btnLimparFiltro.Size = new Size(158, 34);
            btnLimparFiltro.TabIndex = 10;
            btnLimparFiltro.Text = "Limpar Filtro";
            btnLimparFiltro.UseVisualStyleBackColor = true;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(947, 25);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(158, 34);
            btnFiltrar.TabIndex = 9;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // Usuario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1142, 586);
            Controls.Add(panel1);
            Controls.Add(statusStrip1);
            Name = "Usuario";
            Text = "Usuario";
            WindowState = FormWindowState.Maximized;
            Load += Usuario_Load;
            ((System.ComponentModel.ISupportInitialize)dataUsuario).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataUsuario;
        private StatusStrip statusStrip1;
        private Label lblNome;
        private TextBox txtNome;
        private TextBox txtEmail;
        private Label lblEmail;
        private TextBox txtCnpj;
        private Label lblCnpj;
        private Panel panel1;
        private TextBox txtTel;
        private Label lblTelefone;
        private TextBox txtCpf;
        private Label lblCpf;
        private Button btnLimparFiltro;
        private Button btnFiltrar;
        private BindingSource conexaoBindingSource;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn Nome;
        private Button btnAdicionar;
        private Button btnDeletar;
        private Button btnEditar;
        private DataGridViewTextBoxColumn Senha;
        private DataGridViewTextBoxColumn CPF;
        private DataGridViewTextBoxColumn CNPJ;
        private DataGridViewTextBoxColumn Email;
        private DataGridViewTextBoxColumn Telefone;
        private DataGridViewTextBoxColumn Endereço;
        private DataGridViewTextBoxColumn Bairro;
        private DataGridViewTextBoxColumn CEP;
        private DataGridViewTextBoxColumn Numero;
        private DataGridViewTextBoxColumn Cidade;
        private DataGridViewTextBoxColumn UF;
    }
}