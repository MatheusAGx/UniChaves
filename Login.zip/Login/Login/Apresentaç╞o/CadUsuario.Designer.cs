﻿namespace UniChaves.Apresentação
{
    partial class CadUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblEmail = new Label();
            lblCpf = new Label();
            txtCpf = new TextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            label1 = new Label();
            lblCnpj = new Label();
            txtTel = new TextBox();
            txtCnpj = new TextBox();
            selectUf = new ComboBox();
            label2 = new Label();
            txtRua = new TextBox();
            label3 = new Label();
            txtBairro = new TextBox();
            txtCidade = new TextBox();
            txtCep = new TextBox();
            txtNumero = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnCancelar = new Button();
            btnSalvar = new Button();
            btnVoltar = new Button();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(46, 28);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(43, 15);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(340, 27);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(39, 15);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email:";
            // 
            // lblCpf
            // 
            lblCpf.AutoSize = true;
            lblCpf.Location = new Point(59, 68);
            lblCpf.Margin = new Padding(2, 0, 2, 0);
            lblCpf.Name = "lblCpf";
            lblCpf.Size = new Size(31, 15);
            lblCpf.TabIndex = 2;
            lblCpf.Text = "CPF:";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(95, 66);
            txtCpf.Margin = new Padding(2);
            txtCpf.MaxLength = 11;
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(134, 23);
            txtCpf.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(384, 25);
            txtEmail.Margin = new Padding(2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(254, 23);
            txtEmail.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(95, 26);
            txtNome.Margin = new Padding(2);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(236, 23);
            txtNome.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(438, 68);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 6;
            label1.Text = "Telefone:";
            // 
            // lblCnpj
            // 
            lblCnpj.AutoSize = true;
            lblCnpj.Location = new Point(239, 68);
            lblCnpj.Margin = new Padding(2, 0, 2, 0);
            lblCnpj.Name = "lblCnpj";
            lblCnpj.Size = new Size(37, 15);
            lblCnpj.TabIndex = 7;
            lblCnpj.Text = "CNPJ:";
            // 
            // txtTel
            // 
            txtTel.Location = new Point(499, 66);
            txtTel.Margin = new Padding(2);
            txtTel.MaxLength = 11;
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(139, 23);
            txtTel.TabIndex = 8;
            // 
            // txtCnpj
            // 
            txtCnpj.Location = new Point(281, 66);
            txtCnpj.Margin = new Padding(2);
            txtCnpj.MaxLength = 14;
            txtCnpj.Name = "txtCnpj";
            txtCnpj.Size = new Size(147, 23);
            txtCnpj.TabIndex = 9;
            // 
            // selectUf
            // 
            selectUf.FormattingEnabled = true;
            selectUf.Location = new Point(594, 142);
            selectUf.Margin = new Padding(2);
            selectUf.Name = "selectUf";
            selectUf.Size = new Size(45, 23);
            selectUf.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(353, 106);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 11;
            label2.Text = "Bairro: ";
            // 
            // txtRua
            // 
            txtRua.Location = new Point(95, 104);
            txtRua.Margin = new Padding(2);
            txtRua.Name = "txtRua";
            txtRua.Size = new Size(255, 23);
            txtRua.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F);
            label3.Location = new Point(59, 106);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(30, 15);
            label3.TabIndex = 13;
            label3.Text = "Rua:";
            // 
            // txtBairro
            // 
            txtBairro.Location = new Point(397, 104);
            txtBairro.Margin = new Padding(2);
            txtBairro.Name = "txtBairro";
            txtBairro.Size = new Size(241, 23);
            txtBairro.TabIndex = 14;
            // 
            // txtCidade
            // 
            txtCidade.Location = new Point(97, 143);
            txtCidade.Margin = new Padding(2);
            txtCidade.Name = "txtCidade";
            txtCidade.Size = new Size(133, 23);
            txtCidade.TabIndex = 15;
            // 
            // txtCep
            // 
            txtCep.Location = new Point(281, 143);
            txtCep.Margin = new Padding(2);
            txtCep.Name = "txtCep";
            txtCep.Size = new Size(147, 23);
            txtCep.TabIndex = 16;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(499, 143);
            txtNumero.Margin = new Padding(2);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(54, 23);
            txtNumero.TabIndex = 17;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(43, 147);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 18;
            label4.Text = "Cidade:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(245, 145);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(31, 15);
            label5.TabIndex = 19;
            label5.Text = "CEP:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(438, 145);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(54, 15);
            label6.TabIndex = 20;
            label6.Text = "Número:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(564, 145);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(24, 15);
            label7.TabIndex = 21;
            label7.Text = "UF:";
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(564, 242);
            btnCancelar.Margin = new Padding(2);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(78, 20);
            btnCancelar.TabIndex = 22;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(474, 242);
            btnSalvar.Margin = new Padding(2);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(78, 20);
            btnSalvar.TabIndex = 23;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(95, 242);
            btnVoltar.Margin = new Padding(2);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(78, 20);
            btnVoltar.TabIndex = 24;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(232, 187);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 28;
            label8.Text = "Status:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(431, 187);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(64, 15);
            label9.TabIndex = 27;
            label9.Text = "Permissão:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(23, 187);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(65, 15);
            label10.TabIndex = 25;
            label10.Text = "Instituição:";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "FT", "FCA", "Cotil" });
            comboBox1.Location = new Point(97, 185);
            comboBox1.Margin = new Padding(2);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(134, 23);
            comboBox1.TabIndex = 31;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Ativo", "Inativo" });
            comboBox2.Location = new Point(281, 185);
            comboBox2.Margin = new Padding(2);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(147, 23);
            comboBox2.TabIndex = 32;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Administrativo", "Funcionário", "Aluno" });
            comboBox3.Location = new Point(499, 185);
            comboBox3.Margin = new Padding(2);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(139, 23);
            comboBox3.TabIndex = 33;
            // 
            // CadUsuario
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(691, 284);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(btnVoltar);
            Controls.Add(btnSalvar);
            Controls.Add(btnCancelar);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtNumero);
            Controls.Add(txtCep);
            Controls.Add(txtCidade);
            Controls.Add(txtBairro);
            Controls.Add(label3);
            Controls.Add(txtRua);
            Controls.Add(label2);
            Controls.Add(selectUf);
            Controls.Add(txtCnpj);
            Controls.Add(txtTel);
            Controls.Add(lblCnpj);
            Controls.Add(label1);
            Controls.Add(txtNome);
            Controls.Add(txtEmail);
            Controls.Add(txtCpf);
            Controls.Add(lblCpf);
            Controls.Add(lblEmail);
            Controls.Add(lblNome);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(2);
            Name = "CadUsuario";
            RightToLeftLayout = true;
            Text = "Cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblEmail;
        private Label lblCpf;
        private TextBox txtCpf;
        private TextBox txtEmail;
        private TextBox txtNome;
        private Label label1;
        private Label lblCnpj;
        private TextBox txtTel;
        private TextBox txtCnpj;
        private ComboBox selectUf;
        private Label label2;
        private TextBox txtRua;
        private Label label3;
        private TextBox txtBairro;
        private TextBox txtCidade;
        private TextBox txtCep;
        private TextBox txtNumero;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btnCancelar;
        private Button btnSalvar;
        private Button btnVoltar;
        private Label label8;
        private Label label9;
        private Label label10;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
    }
}