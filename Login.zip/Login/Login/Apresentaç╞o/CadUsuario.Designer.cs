﻿namespace UniChaves.Apresentação
{
    partial class CadUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblEmail = new Label();
            lblCpf = new Label();
            txtCpf = new TextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            label1 = new Label();
            lblCnpj = new Label();
            txtTel = new TextBox();
            txtCnpj = new TextBox();
            selectUf = new ComboBox();
            label2 = new Label();
            txtRua = new TextBox();
            label3 = new Label();
            txtBairro = new TextBox();
            txtCidade = new TextBox();
            txtCep = new TextBox();
            txtNumero = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnCancelar = new Button();
            btnSalvar = new Button();
            btnVoltar = new Button();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(65, 46);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(65, 25);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(485, 45);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(58, 25);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email:";
            // 
            // lblCpf
            // 
            lblCpf.AutoSize = true;
            lblCpf.Location = new Point(84, 113);
            lblCpf.Name = "lblCpf";
            lblCpf.Size = new Size(46, 25);
            lblCpf.TabIndex = 2;
            lblCpf.Text = "CPF:";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(136, 110);
            txtCpf.MaxLength = 11;
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(190, 31);
            txtCpf.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(549, 42);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(361, 31);
            txtEmail.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(136, 43);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(336, 31);
            txtNome.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(626, 113);
            label1.Name = "label1";
            label1.Size = new Size(81, 25);
            label1.TabIndex = 6;
            label1.Text = "Telefone:";
            // 
            // lblCnpj
            // 
            lblCnpj.AutoSize = true;
            lblCnpj.Location = new Point(341, 113);
            lblCnpj.Name = "lblCnpj";
            lblCnpj.Size = new Size(55, 25);
            lblCnpj.TabIndex = 7;
            lblCnpj.Text = "CNPJ:";
            // 
            // txtTel
            // 
            txtTel.Location = new Point(713, 110);
            txtTel.MaxLength = 11;
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(197, 31);
            txtTel.TabIndex = 8;
            // 
            // txtCnpj
            // 
            txtCnpj.Location = new Point(402, 110);
            txtCnpj.MaxLength = 14;
            txtCnpj.Name = "txtCnpj";
            txtCnpj.Size = new Size(208, 31);
            txtCnpj.TabIndex = 9;
            // 
            // selectUf
            // 
            selectUf.FormattingEnabled = true;
            selectUf.Location = new Point(848, 237);
            selectUf.Name = "selectUf";
            selectUf.Size = new Size(62, 33);
            selectUf.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(504, 177);
            label2.Name = "label2";
            label2.Size = new Size(67, 25);
            label2.TabIndex = 11;
            label2.Text = "Bairro: ";
            // 
            // txtRua
            // 
            txtRua.Location = new Point(136, 174);
            txtRua.Name = "txtRua";
            txtRua.Size = new Size(362, 31);
            txtRua.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F);
            label3.Location = new Point(84, 177);
            label3.Name = "label3";
            label3.Size = new Size(46, 25);
            label3.TabIndex = 13;
            label3.Text = "Rua:";
            // 
            // txtBairro
            // 
            txtBairro.Location = new Point(567, 174);
            txtBairro.Name = "txtBairro";
            txtBairro.Size = new Size(343, 31);
            txtBairro.TabIndex = 14;
            // 
            // txtCidade
            // 
            txtCidade.Location = new Point(138, 239);
            txtCidade.Name = "txtCidade";
            txtCidade.Size = new Size(188, 31);
            txtCidade.TabIndex = 15;
            // 
            // txtCep
            // 
            txtCep.Location = new Point(402, 239);
            txtCep.Name = "txtCep";
            txtCep.Size = new Size(208, 31);
            txtCep.TabIndex = 16;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(713, 239);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(76, 31);
            txtNumero.TabIndex = 17;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(61, 245);
            label4.Name = "label4";
            label4.Size = new Size(71, 25);
            label4.TabIndex = 18;
            label4.Text = "Cidade:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(350, 242);
            label5.Name = "label5";
            label5.Size = new Size(46, 25);
            label5.TabIndex = 19;
            label5.Text = "CEP:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(626, 242);
            label6.Name = "label6";
            label6.Size = new Size(81, 25);
            label6.TabIndex = 20;
            label6.Text = "Número:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(805, 242);
            label7.Name = "label7";
            label7.Size = new Size(37, 25);
            label7.TabIndex = 21;
            label7.Text = "UF:";
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(805, 404);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(112, 34);
            btnCancelar.TabIndex = 22;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(677, 404);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(112, 34);
            btnSalvar.TabIndex = 23;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(136, 404);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(112, 34);
            btnVoltar.TabIndex = 24;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(332, 312);
            label8.Name = "label8";
            label8.Size = new Size(64, 25);
            label8.TabIndex = 28;
            label8.Text = "Status:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(616, 312);
            label9.Name = "label9";
            label9.Size = new Size(96, 25);
            label9.TabIndex = 27;
            label9.Text = "Permissão:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(33, 312);
            label10.Name = "label10";
            label10.Size = new Size(97, 25);
            label10.TabIndex = 25;
            label10.Text = "Instituição:";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "FT", "FCA", "Cotil" });
            comboBox1.Location = new Point(138, 309);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(190, 33);
            comboBox1.TabIndex = 31;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Ativo", "Inativo" });
            comboBox2.Location = new Point(402, 309);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(208, 33);
            comboBox2.TabIndex = 32;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Administrativo", "Funcionário", "Aluno" });
            comboBox3.Location = new Point(713, 309);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(197, 33);
            comboBox3.TabIndex = 33;
            // 
            // CadUsuario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(987, 473);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(btnVoltar);
            Controls.Add(btnSalvar);
            Controls.Add(btnCancelar);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtNumero);
            Controls.Add(txtCep);
            Controls.Add(txtCidade);
            Controls.Add(txtBairro);
            Controls.Add(label3);
            Controls.Add(txtRua);
            Controls.Add(label2);
            Controls.Add(selectUf);
            Controls.Add(txtCnpj);
            Controls.Add(txtTel);
            Controls.Add(lblCnpj);
            Controls.Add(label1);
            Controls.Add(txtNome);
            Controls.Add(txtEmail);
            Controls.Add(txtCpf);
            Controls.Add(lblCpf);
            Controls.Add(lblEmail);
            Controls.Add(lblNome);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CadUsuario";
            Text = "Cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblEmail;
        private Label lblCpf;
        private TextBox txtCpf;
        private TextBox txtEmail;
        private TextBox txtNome;
        private Label label1;
        private Label lblCnpj;
        private TextBox txtTel;
        private TextBox txtCnpj;
        private ComboBox selectUf;
        private Label label2;
        private TextBox txtRua;
        private Label label3;
        private TextBox txtBairro;
        private TextBox txtCidade;
        private TextBox txtCep;
        private TextBox txtNumero;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btnCancelar;
        private Button btnSalvar;
        private Button btnVoltar;
        private Label label8;
        private Label label9;
        private Label label10;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
    }
}