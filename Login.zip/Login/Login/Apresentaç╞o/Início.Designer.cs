﻿namespace UniChaves.Apresentação
{
    partial class Início
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Início));
            menuStrip = new MenuStrip();
            usuariosMenu = new ToolStripMenuItem();
            listarToolStripMenuItem = new ToolStripMenuItem();
            cadastroToolStripMenuItem = new ToolStripMenuItem();
            chavesMenu = new ToolStripMenuItem();
            listarToolStripMenuItem1 = new ToolStripMenuItem();
            cadastroToolStripMenuItem1 = new ToolStripMenuItem();
            ocorrenciasMenu = new ToolStripMenuItem();
            relatoriosMenu = new ToolStripMenuItem();
            configMenu = new ToolStripMenuItem();
            statusStrip = new StatusStrip();
            toolStripStatusLabel = new ToolStripStatusLabel();
            toolTip = new ToolTip(components);
            menuStrip.SuspendLayout();
            statusStrip.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip
            // 
            menuStrip.ImageScalingSize = new Size(32, 32);
            menuStrip.Items.AddRange(new ToolStripItem[] { usuariosMenu, chavesMenu, ocorrenciasMenu, relatoriosMenu, configMenu });
            menuStrip.LayoutStyle = ToolStripLayoutStyle.HorizontalStackWithOverflow;
            menuStrip.Location = new Point(0, 0);
            menuStrip.MdiWindowListItem = configMenu;
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(10, 4, 0, 4);
            menuStrip.Size = new Size(1254, 44);
            menuStrip.TabIndex = 0;
            menuStrip.Text = "MenuStrip";
            // 
            // usuariosMenu
            // 
            usuariosMenu.DropDownItems.AddRange(new ToolStripItem[] { listarToolStripMenuItem, cadastroToolStripMenuItem });
            usuariosMenu.Image = (Image)resources.GetObject("usuariosMenu.Image");
            usuariosMenu.ImageTransparentColor = SystemColors.ActiveBorder;
            usuariosMenu.Name = "usuariosMenu";
            usuariosMenu.Size = new Size(128, 36);
            usuariosMenu.Text = "&Usuários";
            // 
            // listarToolStripMenuItem
            // 
            listarToolStripMenuItem.Name = "listarToolStripMenuItem";
            listarToolStripMenuItem.Size = new Size(185, 34);
            listarToolStripMenuItem.Text = "&Listar";
            listarToolStripMenuItem.Click += listarToolStripMenuItem_Click;
            // 
            // cadastroToolStripMenuItem
            // 
            cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            cadastroToolStripMenuItem.Size = new Size(185, 34);
            cadastroToolStripMenuItem.Text = "&Cadastro";
            cadastroToolStripMenuItem.Click += cadastroToolStripMenuItem_Click;
            // 
            // chavesMenu
            // 
            chavesMenu.DropDownItems.AddRange(new ToolStripItem[] { listarToolStripMenuItem1, cadastroToolStripMenuItem1 });
            chavesMenu.Image = (Image)resources.GetObject("chavesMenu.Image");
            chavesMenu.Name = "chavesMenu";
            chavesMenu.Size = new Size(116, 36);
            chavesMenu.Text = "&Chaves";
            // 
            // listarToolStripMenuItem1
            // 
            listarToolStripMenuItem1.Name = "listarToolStripMenuItem1";
            listarToolStripMenuItem1.Size = new Size(185, 34);
            listarToolStripMenuItem1.Text = "&Listar";
            listarToolStripMenuItem1.Click += listarToolStripMenuItem1_Click;
            // 
            // cadastroToolStripMenuItem1
            // 
            cadastroToolStripMenuItem1.Name = "cadastroToolStripMenuItem1";
            cadastroToolStripMenuItem1.Size = new Size(185, 34);
            cadastroToolStripMenuItem1.Text = "&Cadastro";
            cadastroToolStripMenuItem1.Click += cadastroToolStripMenuItem1_Click;
            // 
            // ocorrenciasMenu
            // 
            ocorrenciasMenu.Image = (Image)resources.GetObject("ocorrenciasMenu.Image");
            ocorrenciasMenu.Name = "ocorrenciasMenu";
            ocorrenciasMenu.Size = new Size(153, 36);
            ocorrenciasMenu.Text = "&Ocorrências";
            // 
            // relatoriosMenu
            // 
            relatoriosMenu.Image = (Image)resources.GetObject("relatoriosMenu.Image");
            relatoriosMenu.Name = "relatoriosMenu";
            relatoriosMenu.Size = new Size(138, 36);
            relatoriosMenu.Text = "&Relatórios";
            // 
            // configMenu
            // 
            configMenu.Image = (Image)resources.GetObject("configMenu.Image");
            configMenu.Name = "configMenu";
            configMenu.Size = new Size(174, 36);
            configMenu.Text = "&Configurações";
            // 
            // statusStrip
            // 
            statusStrip.ImageScalingSize = new Size(24, 24);
            statusStrip.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel });
            statusStrip.Location = new Point(0, 610);
            statusStrip.Name = "statusStrip";
            statusStrip.Padding = new Padding(2, 0, 23, 0);
            statusStrip.Size = new Size(1254, 32);
            statusStrip.TabIndex = 2;
            statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            toolStripStatusLabel.Name = "toolStripStatusLabel";
            toolStripStatusLabel.Size = new Size(60, 25);
            toolStripStatusLabel.Text = "Status";
            // 
            // Início
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1254, 642);
            Controls.Add(statusStrip);
            Controls.Add(menuStrip);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip;
            Margin = new Padding(5, 6, 5, 6);
            Name = "Início";
            Text = "UniChaves";
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem usuariosMenu;
        private System.Windows.Forms.ToolStripMenuItem chavesMenu;
        private System.Windows.Forms.ToolStripMenuItem ocorrenciasMenu;
        private System.Windows.Forms.ToolStripMenuItem relatoriosMenu;
        private System.Windows.Forms.ToolStripMenuItem configMenu;
        private System.Windows.Forms.ToolTip toolTip;
        private ToolStripMenuItem cadastroToolStripMenuItem;
        private ToolStripMenuItem cadastroToolStripMenuItem1;
        private ToolStripMenuItem registrarToolStripMenuItem;
        private ToolStripMenuItem listarToolStripMenuItem;
        private ToolStripMenuItem listarToolStripMenuItem1;
    }
}



