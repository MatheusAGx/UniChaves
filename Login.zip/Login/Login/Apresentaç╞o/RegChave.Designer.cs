﻿namespace UniChaves.Apresentação
{
    partial class RegChave
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            statusStrip = new StatusStrip();
            toolStripStatusLabel = new ToolStripStatusLabel();
            toolTip = new ToolTip(components);
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            richTextBox1 = new RichTextBox();
            label1 = new Label();
            comboInstituicao = new ComboBox();
            lblInstituicao = new Label();
            lblTelefone = new Label();
            txtTelefone = new TextBox();
            txtCpfCnpj = new TextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            label3 = new Label();
            lblEmail = new Label();
            lblNome = new Label();
            statusStrip.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // statusStrip
            // 
            statusStrip.ImageScalingSize = new Size(24, 24);
            statusStrip.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel });
            statusStrip.Location = new Point(0, 317);
            statusStrip.Name = "statusStrip";
            statusStrip.Padding = new Padding(1, 0, 16, 0);
            statusStrip.Size = new Size(741, 22);
            statusStrip.TabIndex = 2;
            statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            toolStripStatusLabel.Name = "toolStripStatusLabel";
            toolStripStatusLabel.Size = new Size(39, 17);
            toolStripStatusLabel.Text = "Status";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(richTextBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(comboInstituicao);
            panel1.Controls.Add(lblInstituicao);
            panel1.Controls.Add(lblTelefone);
            panel1.Controls.Add(txtTelefone);
            panel1.Controls.Add(txtCpfCnpj);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(txtNome);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(lblNome);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(2, 2, 2, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(741, 317);
            panel1.TabIndex = 4;
            // 
            // button2
            // 
            button2.Location = new Point(112, 286);
            button2.Margin = new Padding(2, 2, 2, 2);
            button2.Name = "button2";
            button2.Size = new Size(78, 20);
            button2.TabIndex = 13;
            button2.Text = "Cancelar";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(621, 286);
            button1.Margin = new Padding(2, 2, 2, 2);
            button1.Name = "button1";
            button1.Size = new Size(78, 20);
            button1.TabIndex = 12;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(112, 99);
            richTextBox1.Margin = new Padding(2, 2, 2, 2);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(588, 176);
            richTextBox1.TabIndex = 11;
            richTextBox1.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 99);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 10;
            label1.Text = "Descrição:";
            // 
            // comboInstituicao
            // 
            comboInstituicao.FormattingEnabled = true;
            comboInstituicao.Location = new Point(555, 58);
            comboInstituicao.Margin = new Padding(2, 2, 2, 2);
            comboInstituicao.Name = "comboInstituicao";
            comboInstituicao.Size = new Size(145, 23);
            comboInstituicao.TabIndex = 9;
            // 
            // lblInstituicao
            // 
            lblInstituicao.AutoSize = true;
            lblInstituicao.Location = new Point(477, 61);
            lblInstituicao.Margin = new Padding(2, 0, 2, 0);
            lblInstituicao.Name = "lblInstituicao";
            lblInstituicao.Size = new Size(65, 15);
            lblInstituicao.TabIndex = 8;
            lblInstituicao.Text = "Instituição:";
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(260, 61);
            lblTelefone.Margin = new Padding(2, 0, 2, 0);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(54, 15);
            lblTelefone.TabIndex = 7;
            lblTelefone.Text = "Telefone:";
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(321, 59);
            txtTelefone.Margin = new Padding(2, 2, 2, 2);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(145, 23);
            txtTelefone.TabIndex = 6;
            // 
            // txtCpfCnpj
            // 
            txtCpfCnpj.Location = new Point(112, 59);
            txtCpfCnpj.Margin = new Padding(2, 2, 2, 2);
            txtCpfCnpj.Name = "txtCpfCnpj";
            txtCpfCnpj.Size = new Size(134, 23);
            txtCpfCnpj.TabIndex = 5;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(431, 25);
            txtEmail.Margin = new Padding(2, 2, 2, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(269, 23);
            txtEmail.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(112, 25);
            txtNome.Margin = new Padding(2, 2, 2, 2);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(271, 23);
            txtNome.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(43, 61);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 2;
            label3.Text = "CPF/CNPJ:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(386, 27);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(43, 15);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Nome:";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(63, 27);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(43, 15);
            lblNome.TabIndex = 0;
            lblNome.Text = "Chave:";
            // 
            // RegChave
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(741, 339);
            Controls.Add(panel1);
            Controls.Add(statusStrip);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            IsMdiContainer = true;
            Margin = new Padding(4, 4, 4, 4);
            Name = "RegChave";
            Text = "RegChave";
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private Panel panel1;
        private Label label3;
        private Label lblEmail;
        private Label lblNome;
        private TextBox txtEmail;
        private TextBox txtNome;
        private Label lblTelefone;
        private TextBox txtTelefone;
        private TextBox txtCpfCnpj;
        private Label lblInstituicao;
        private ComboBox comboInstituicao;
        private Button button2;
        private Button button1;
        private RichTextBox richTextBox1;
        private Label label1;
    }
}



