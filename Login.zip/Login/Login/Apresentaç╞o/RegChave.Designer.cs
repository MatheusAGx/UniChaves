﻿namespace UniChaves.Apresentação
{
    partial class RegChave
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            statusStrip = new StatusStrip();
            toolStripStatusLabel = new ToolStripStatusLabel();
            toolTip = new ToolTip(components);
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            richTextBox1 = new RichTextBox();
            label1 = new Label();
            comboInstituicao = new ComboBox();
            lblInstituicao = new Label();
            lblTelefone = new Label();
            txtTelefone = new TextBox();
            txtCpfCnpj = new TextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            label3 = new Label();
            lblEmail = new Label();
            lblNome = new Label();
            statusStrip.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // statusStrip
            // 
            statusStrip.ImageScalingSize = new Size(24, 24);
            statusStrip.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel });
            statusStrip.Location = new Point(0, 533);
            statusStrip.Name = "statusStrip";
            statusStrip.Padding = new Padding(2, 0, 23, 0);
            statusStrip.Size = new Size(1058, 32);
            statusStrip.TabIndex = 2;
            statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            toolStripStatusLabel.Name = "toolStripStatusLabel";
            toolStripStatusLabel.Size = new Size(60, 25);
            toolStripStatusLabel.Text = "Status";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(richTextBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(comboInstituicao);
            panel1.Controls.Add(lblInstituicao);
            panel1.Controls.Add(lblTelefone);
            panel1.Controls.Add(txtTelefone);
            panel1.Controls.Add(txtCpfCnpj);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(txtNome);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(lblNome);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1058, 533);
            panel1.TabIndex = 4;
            // 
            // button2
            // 
            button2.Location = new Point(160, 476);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 13;
            button2.Text = "Cancelar";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(887, 476);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 12;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(160, 165);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(839, 291);
            richTextBox1.TabIndex = 11;
            richTextBox1.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(62, 165);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 10;
            label1.Text = "Descrição:";
            // 
            // comboInstituicao
            // 
            comboInstituicao.FormattingEnabled = true;
            comboInstituicao.Location = new Point(793, 97);
            comboInstituicao.Name = "comboInstituicao";
            comboInstituicao.Size = new Size(206, 33);
            comboInstituicao.TabIndex = 9;
            // 
            // lblInstituicao
            // 
            lblInstituicao.AutoSize = true;
            lblInstituicao.Location = new Point(681, 102);
            lblInstituicao.Name = "lblInstituicao";
            lblInstituicao.Size = new Size(97, 25);
            lblInstituicao.TabIndex = 8;
            lblInstituicao.Text = "Instituição:";
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(372, 102);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(81, 25);
            lblTelefone.TabIndex = 7;
            lblTelefone.Text = "Telefone:";
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(459, 99);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(205, 31);
            txtTelefone.TabIndex = 6;
            // 
            // txtCpfCnpj
            // 
            txtCpfCnpj.Location = new Point(160, 99);
            txtCpfCnpj.Name = "txtCpfCnpj";
            txtCpfCnpj.Size = new Size(190, 31);
            txtCpfCnpj.TabIndex = 5;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(616, 42);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(383, 31);
            txtEmail.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(160, 42);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(385, 31);
            txtNome.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(62, 102);
            label3.Name = "label3";
            label3.Size = new Size(92, 25);
            label3.TabIndex = 2;
            label3.Text = "CPF/CNPJ:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(551, 45);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(65, 25);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Nome:";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(90, 45);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(64, 25);
            lblNome.TabIndex = 0;
            lblNome.Text = "Chave:";
            // 
            // RegChave
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1058, 565);
            Controls.Add(panel1);
            Controls.Add(statusStrip);
            FormBorderStyle = FormBorderStyle.None;
            IsMdiContainer = true;
            Margin = new Padding(5, 6, 5, 6);
            Name = "RegChave";
            Text = "RegChave";
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private Panel panel1;
        private Label label3;
        private Label lblEmail;
        private Label lblNome;
        private TextBox txtEmail;
        private TextBox txtNome;
        private Label lblTelefone;
        private TextBox txtTelefone;
        private TextBox txtCpfCnpj;
        private Label lblInstituicao;
        private ComboBox comboInstituicao;
        private Button button2;
        private Button button1;
        private RichTextBox richTextBox1;
        private Label label1;
    }
}



