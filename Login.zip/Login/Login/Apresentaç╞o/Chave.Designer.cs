﻿namespace UniChaves.Apresentação
{
    partial class Chave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnInstituicao = new Label();
            textBox1 = new TextBox();
            btnNome = new Label();
            textBox2 = new TextBox();
            btnStatus = new Label();
            radioDisponivel = new RadioButton();
            radioOcupado = new RadioButton();
            radioReservado = new RadioButton();
            dataGridView1 = new DataGridView();
            conexaoBindingSource = new BindingSource(components);
            btnFiltrar = new Button();
            btnLimparFiltro = new Button();
            btnEditar = new Button();
            btnDeletar = new Button();
            statusStrip1 = new StatusStrip();
            btnRegistrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btnInstituicao
            // 
            btnInstituicao.AutoSize = true;
            btnInstituicao.Location = new Point(460, 40);
            btnInstituicao.Name = "btnInstituicao";
            btnInstituicao.Size = new Size(97, 25);
            btnInstituicao.TabIndex = 1;
            btnInstituicao.Text = "Instituição:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(122, 37);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(320, 31);
            textBox1.TabIndex = 2;
            // 
            // btnNome
            // 
            btnNome.AutoSize = true;
            btnNome.Location = new Point(51, 40);
            btnNome.Name = "btnNome";
            btnNome.Size = new Size(65, 25);
            btnNome.TabIndex = 0;
            btnNome.Text = "Nome:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(563, 37);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(362, 31);
            textBox2.TabIndex = 4;
            // 
            // btnStatus
            // 
            btnStatus.AutoSize = true;
            btnStatus.Location = new Point(52, 90);
            btnStatus.Name = "btnStatus";
            btnStatus.Size = new Size(64, 25);
            btnStatus.TabIndex = 5;
            btnStatus.Text = "Status:";
            // 
            // radioDisponivel
            // 
            radioDisponivel.AutoSize = true;
            radioDisponivel.Location = new Point(122, 90);
            radioDisponivel.Name = "radioDisponivel";
            radioDisponivel.Size = new Size(120, 29);
            radioDisponivel.TabIndex = 6;
            radioDisponivel.TabStop = true;
            radioDisponivel.Text = "Disponível";
            radioDisponivel.UseVisualStyleBackColor = true;
            // 
            // radioOcupado
            // 
            radioOcupado.AutoSize = true;
            radioOcupado.Location = new Point(248, 90);
            radioOcupado.Name = "radioOcupado";
            radioOcupado.Size = new Size(111, 29);
            radioOcupado.TabIndex = 7;
            radioOcupado.TabStop = true;
            radioOcupado.Text = "Ocupado";
            radioOcupado.UseVisualStyleBackColor = true;
            // 
            // radioReservado
            // 
            radioReservado.AutoSize = true;
            radioReservado.Location = new Point(365, 90);
            radioReservado.Name = "radioReservado";
            radioReservado.Size = new Size(119, 29);
            radioReservado.TabIndex = 8;
            radioReservado.TabStop = true;
            radioReservado.Text = "Reservado";
            radioReservado.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.DataSource = conexaoBindingSource;
            dataGridView1.Location = new Point(51, 157);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1036, 315);
            dataGridView1.TabIndex = 9;
            // 
            // conexaoBindingSource
            // 
            conexaoBindingSource.DataSource = typeof(Conexao);
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(950, 35);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(137, 34);
            btnFiltrar.TabIndex = 10;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            // 
            // btnLimparFiltro
            // 
            btnLimparFiltro.Location = new Point(950, 85);
            btnLimparFiltro.Name = "btnLimparFiltro";
            btnLimparFiltro.Size = new Size(137, 34);
            btnLimparFiltro.TabIndex = 11;
            btnLimparFiltro.Text = "Limpar Filtros";
            btnLimparFiltro.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(51, 488);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(137, 34);
            btnEditar.TabIndex = 12;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnDeletar
            // 
            btnDeletar.Location = new Point(213, 488);
            btnDeletar.Name = "btnDeletar";
            btnDeletar.Size = new Size(137, 34);
            btnDeletar.TabIndex = 13;
            btnDeletar.Text = "Deletar";
            btnDeletar.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Location = new Point(0, 564);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1142, 22);
            statusStrip1.TabIndex = 14;
            statusStrip1.Text = "statusStrip1";
            // 
            // btnRegistrar
            // 
            btnRegistrar.Location = new Point(950, 488);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(137, 34);
            btnRegistrar.TabIndex = 15;
            btnRegistrar.Text = "Registrar";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // Chave
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1142, 586);
            Controls.Add(btnRegistrar);
            Controls.Add(statusStrip1);
            Controls.Add(btnDeletar);
            Controls.Add(btnEditar);
            Controls.Add(btnLimparFiltro);
            Controls.Add(btnFiltrar);
            Controls.Add(dataGridView1);
            Controls.Add(radioReservado);
            Controls.Add(radioOcupado);
            Controls.Add(radioDisponivel);
            Controls.Add(btnStatus);
            Controls.Add(textBox2);
            Controls.Add(btnNome);
            Controls.Add(textBox1);
            Controls.Add(btnInstituicao);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Chave";
            Text = "Chaves";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label btnInstituicao;
        private TextBox textBox1;
        private Label btnNome;
        private TextBox textBox2;
        private Label btnStatus;
        private RadioButton radioDisponivel;
        private RadioButton radioOcupado;
        private RadioButton radioReservado;
        private DataGridView dataGridView1;
        private Button btnFiltrar;
        private Button btnLimparFiltro;
        private Button btnEditar;
        private Button btnDeletar;
        private BindingSource conexaoBindingSource;
        private StatusStrip statusStrip1;
        private Button btnRegistrar;
    }
}