﻿namespace UniChaves.Apresentação
{
    partial class Chave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnInstituicao = new Label();
            textBox1 = new TextBox();
            btnNome = new Label();
            textBox2 = new TextBox();
            btnStatus = new Label();
            radioDisponivel = new RadioButton();
            radioOcupado = new RadioButton();
            radioReservado = new RadioButton();
            dataGridView1 = new DataGridView();
            conexaoBindingSource = new BindingSource(components);
            btnFiltrar = new Button();
            btnLimparFiltro = new Button();
            btnEditar = new Button();
            btnDeletar = new Button();
            statusStrip1 = new StatusStrip();
            btnRegistrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btnInstituicao
            // 
            btnInstituicao.AutoSize = true;
            btnInstituicao.Location = new Point(322, 24);
            btnInstituicao.Margin = new Padding(2, 0, 2, 0);
            btnInstituicao.Name = "btnInstituicao";
            btnInstituicao.Size = new Size(65, 15);
            btnInstituicao.TabIndex = 1;
            btnInstituicao.Text = "Instituição:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(85, 22);
            textBox1.Margin = new Padding(2, 2, 2, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(225, 23);
            textBox1.TabIndex = 2;
            // 
            // btnNome
            // 
            btnNome.AutoSize = true;
            btnNome.Location = new Point(36, 24);
            btnNome.Margin = new Padding(2, 0, 2, 0);
            btnNome.Name = "btnNome";
            btnNome.Size = new Size(43, 15);
            btnNome.TabIndex = 0;
            btnNome.Text = "Nome:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(394, 22);
            textBox2.Margin = new Padding(2, 2, 2, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(255, 23);
            textBox2.TabIndex = 4;
            // 
            // btnStatus
            // 
            btnStatus.AutoSize = true;
            btnStatus.Location = new Point(36, 54);
            btnStatus.Margin = new Padding(2, 0, 2, 0);
            btnStatus.Name = "btnStatus";
            btnStatus.Size = new Size(42, 15);
            btnStatus.TabIndex = 5;
            btnStatus.Text = "Status:";
            // 
            // radioDisponivel
            // 
            radioDisponivel.AutoSize = true;
            radioDisponivel.Location = new Point(85, 54);
            radioDisponivel.Margin = new Padding(2, 2, 2, 2);
            radioDisponivel.Name = "radioDisponivel";
            radioDisponivel.Size = new Size(80, 19);
            radioDisponivel.TabIndex = 6;
            radioDisponivel.TabStop = true;
            radioDisponivel.Text = "Disponível";
            radioDisponivel.UseVisualStyleBackColor = true;
            // 
            // radioOcupado
            // 
            radioOcupado.AutoSize = true;
            radioOcupado.Location = new Point(174, 54);
            radioOcupado.Margin = new Padding(2, 2, 2, 2);
            radioOcupado.Name = "radioOcupado";
            radioOcupado.Size = new Size(74, 19);
            radioOcupado.TabIndex = 7;
            radioOcupado.TabStop = true;
            radioOcupado.Text = "Ocupado";
            radioOcupado.UseVisualStyleBackColor = true;
            // 
            // radioReservado
            // 
            radioReservado.AutoSize = true;
            radioReservado.Location = new Point(256, 54);
            radioReservado.Margin = new Padding(2, 2, 2, 2);
            radioReservado.Name = "radioReservado";
            radioReservado.Size = new Size(79, 19);
            radioReservado.TabIndex = 8;
            radioReservado.TabStop = true;
            radioReservado.Text = "Reservado";
            radioReservado.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.DataSource = conexaoBindingSource;
            dataGridView1.Location = new Point(36, 94);
            dataGridView1.Margin = new Padding(2, 2, 2, 2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(725, 189);
            dataGridView1.TabIndex = 9;
            // 
            // conexaoBindingSource
            // 
            conexaoBindingSource.DataSource = typeof(Conexao);
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(665, 21);
            btnFiltrar.Margin = new Padding(2, 2, 2, 2);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(96, 20);
            btnFiltrar.TabIndex = 10;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            // 
            // btnLimparFiltro
            // 
            btnLimparFiltro.Location = new Point(665, 51);
            btnLimparFiltro.Margin = new Padding(2, 2, 2, 2);
            btnLimparFiltro.Name = "btnLimparFiltro";
            btnLimparFiltro.Size = new Size(96, 20);
            btnLimparFiltro.TabIndex = 11;
            btnLimparFiltro.Text = "Limpar Filtros";
            btnLimparFiltro.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(36, 293);
            btnEditar.Margin = new Padding(2, 2, 2, 2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(96, 20);
            btnEditar.TabIndex = 12;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnDeletar
            // 
            btnDeletar.Location = new Point(149, 293);
            btnDeletar.Margin = new Padding(2, 2, 2, 2);
            btnDeletar.Name = "btnDeletar";
            btnDeletar.Size = new Size(96, 20);
            btnDeletar.TabIndex = 13;
            btnDeletar.Text = "Deletar";
            btnDeletar.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Location = new Point(0, 330);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Padding = new Padding(1, 0, 10, 0);
            statusStrip1.Size = new Size(799, 22);
            statusStrip1.TabIndex = 14;
            statusStrip1.Text = "statusStrip1";
            // 
            // btnRegistrar
            // 
            btnRegistrar.Location = new Point(665, 293);
            btnRegistrar.Margin = new Padding(2, 2, 2, 2);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(96, 20);
            btnRegistrar.TabIndex = 15;
            btnRegistrar.Text = "Registrar";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // Chave
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(799, 352);
            Controls.Add(btnRegistrar);
            Controls.Add(statusStrip1);
            Controls.Add(btnDeletar);
            Controls.Add(btnEditar);
            Controls.Add(btnLimparFiltro);
            Controls.Add(btnFiltrar);
            Controls.Add(dataGridView1);
            Controls.Add(radioReservado);
            Controls.Add(radioOcupado);
            Controls.Add(radioDisponivel);
            Controls.Add(btnStatus);
            Controls.Add(textBox2);
            Controls.Add(btnNome);
            Controls.Add(textBox1);
            Controls.Add(btnInstituicao);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(2, 2, 2, 2);
            Name = "Chave";
            Text = "Chaves";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label btnInstituicao;
        private TextBox textBox1;
        private Label btnNome;
        private TextBox textBox2;
        private Label btnStatus;
        private RadioButton radioDisponivel;
        private RadioButton radioOcupado;
        private RadioButton radioReservado;
        private DataGridView dataGridView1;
        private Button btnFiltrar;
        private Button btnLimparFiltro;
        private Button btnEditar;
        private Button btnDeletar;
        private BindingSource conexaoBindingSource;
        private StatusStrip statusStrip1;
        private Button btnRegistrar;
    }
}