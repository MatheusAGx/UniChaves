using UniChaves.Apresenta��o;

namespace Login
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
#pragma warning disable CS0028 // "Program.Main(Application)" tem a assinatura incorreta para ser um ponto de entrada
        static void Main()
#pragma warning restore CS0028 // "Program.Main(Application)" tem a assinatura incorreta para ser um ponto de entrada
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            ApplicationConfiguration.Initialize();
            Application.Run(new Login());
        }
    }
}