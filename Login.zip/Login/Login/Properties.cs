﻿namespace UniChaves
{
    internal class Properties
    {
        public static object Resources { get; internal set; }
    }
}